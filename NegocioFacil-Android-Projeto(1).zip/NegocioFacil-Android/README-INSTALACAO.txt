NEGÓCIO FÁCIL — projeto Android (versão 0.1.0)

Este ZIP contém o projeto-fonte Android com o protótipo web incorporado em assets.
Ainda NÃO é um APK compilado.

COMO GERAR O APK:
1. Num computador, instalar Android Studio e o Android SDK (API 35).
2. Extrair esta pasta.
3. No Android Studio, escolher Open e selecionar a pasta NegocioFacil-Android.
4. Aguardar a sincronização Gradle e instalar os componentes pedidos.
5. Selecionar Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste costuma ficar em app/build/outputs/apk/debug/app-debug.apk.
7. Transferir o APK para o Android e instalar, permitindo instalação desta origem quando solicitado.

NOTAS:
- A aplicação abre a interface local incorporada e não depende de internet para o ecrã principal.
- Os dados são guardados no armazenamento local da aplicação (WebView/localStorage).
- Desinstalar a aplicação pode apagar os dados. Exporte cópias de segurança dentro do app.
- Esta versão não sincroniza dados entre telemóveis e não é software de facturação fiscal certificado.
- Antes de distribuição comercial, testar em diferentes Android, preparar ícone/assinatura de lançamento e reforçar segurança.

ALTERNATIVA: COMPILAR NA NUVEM PELO GITHUB
1. Crie uma conta no GitHub e um repositório novo.
2. Envie o conteúdo desta pasta para a branch main.
3. Abra o separador Actions do repositório.
4. Execute o workflow "Build Android APK" (ou aguarde o build após o push).
5. Quando terminar, abra a execução e descarregue o artefacto negocio-facil-debug-apk.
6. Extraia o artefacto; dentro estará app-debug.apk.
Este é um APK de depuração para testes, não uma versão assinada para distribuição pública.
